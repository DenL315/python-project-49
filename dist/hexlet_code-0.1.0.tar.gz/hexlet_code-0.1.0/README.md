### Hexlet tests and linter status:
[![Actions Status](https://github.com/DenL315/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DenL315/python-project-49/actions)
https://asciinema.org/a/hK0BwGrTOkuGdM6L5WuBwNcIz 
https://asciinema.org/a/KH2rikDiiriRAKUW4h0yYQUM6 
https://asciinema.org/a/lcWkHCKYKhQDcfbzw6OaQaaZo
https://asciinema.org/a/dWqbKsVEAZSXPUcBBBEDetuAK
