### Hexlet tests and linter status:
[![Actions Status](https://github.com/DenL315/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DenL315/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/edb7e042d81efe3c42cc/maintainability)](https://codeclimate.com/github/DenL315/python-project-49/maintainability)
https://asciinema.org/a/hK0BwGrTOkuGdM6L5WuBwNcIz 
https://asciinema.org/a/KH2rikDiiriRAKUW4h0yYQUM6 
https://asciinema.org/a/lcWkHCKYKhQDcfbzw6OaQaaZo
https://asciinema.org/a/dWqbKsVEAZSXPUcBBBEDetuAK
https://asciinema.org/a/w264MexU9V38CrGZnQ3gmaAPX
