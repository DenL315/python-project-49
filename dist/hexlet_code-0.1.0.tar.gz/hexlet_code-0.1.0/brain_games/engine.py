import prompt
WIN = 3


def play(game):
    name = prompt.string('Welcome to the Brain Games!\nMay I have your name? ')
    print(f'Hello, {name}!')
    print(game.QUESTION)
    for _ in range(WIN):
        question, correct_answer = game.generate_task()
        print(f"Question: {question}")
        answer = prompt.string('Your answer: ')
        if answer == correct_answer:
            print('Correct!')
        else:
            print(f"'{answer}' is wrong answer ;(. Correct answer is '{correct_answer}'.\nLet's try again, {name}!")
            break
    else:
        print(f'Congratulations, {name}!')
